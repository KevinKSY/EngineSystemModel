/*
 * rtGetNaN.h
 *
 * Code generation for function 'GetCompCombGas'
 *
 * C source code generated on: Tue Jul 31 11:27:42 2012
 *
 */

#ifndef __RTGETNAN_H__
#define __RTGETNAN_H__

#include <stddef.h>
#include "rtwtypes.h"
#include "rt_nonfinite.h"

extern real_T rtGetNaN(void);
extern real32_T rtGetNaNF(void);

#endif
/* End of code generation (rtGetNaN.h) */
